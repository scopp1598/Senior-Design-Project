#include <stdio.h>
#include <stdlib.h>

int main() {

    //Initial value of the file
    char init_val[255];

    //The test value the is going to be adjusted
    char test_val[255];

    char debug_val[255];

    //Declaring an input file pointer
    FILE *fp;

    //Assigning the location of a file to the file pointer and giving it write permissions
    fp = fopen("test.txt", "w+");

    //DEBUG TESTING
    if (fp == NULL){
        printf("File did not open correctly\n");
        return -1;
    } else {
        printf("File has open correctly\n");
    }

    //Get initial value of the file
//    fgets(init_val, 255, fp);
    //Show value of the file
//    printf("init_val: %s\n", init_val);

    //Prompt user for debug value
    printf("Please enter value for debug testing: ");
    //Get the value from the user
    gets(debug_val);
    //Write the value to the file
    fputs(debug_val, fp);

    //Get current contents of file
    fgets(debug_val, 255, fp);
    //Check the file to see if write occurred
    printf("Current contents of file: %s\n", debug_val);
    //END DEBUG

    //TODO: Work on getting write output working correctly

//    while (fp){
//        fgets(test_val, 255, fp);
//
//        if (test_val > 0){
//            atoi(test_val) - 1;
//            fputs(test_val, fp);
//        } else if (test_val < 0){
//            atoi(test_val) + 1;
//            fputs(test_val, fp);
//        } else if (test_val == 0){
//            fputs(test_val, fp);
//        }
//
//        getchar();
//
//        printf("test_val: %s\n", test_val);
//    }

    //ALWAYS CLOSE THE FILES YOU OPEN
    fclose(fp);
    return 0;
}